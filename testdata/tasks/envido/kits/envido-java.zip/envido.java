import java.lang.*;
import java.util.*;

public class envido {
    public static int envido(int numero1, String palo1, int numero2, String palo2, int numero3, String palo3) {
        // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
    }
}
